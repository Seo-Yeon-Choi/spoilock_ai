r"""
Gemini API 자체 응답 속도 점검 (판별 서버와 무관하게 Gemini만 호출)

  .\.venv\Scripts\python.exe gemini_ping.py                       # 현재 모델로 5회
  .\.venv\Scripts\python.exe gemini_ping.py --model gemini-2.5-flash-lite
  .\.venv\Scripts\python.exe gemini_ping.py --count 10 --gap 2

- SDK 자동 재시도를 끄고(1회 시도) 호출하므로, 429(한도 초과)·503(과부하)이
  '느린 응답'으로 숨지 않고 오류로 그대로 보입니다.
- 아주 짧은 요청("OK"만 답하기)이라, 여기서도 느리면 우리 코드가 아니라 API 쪽 문제입니다.
"""
import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from check_spoiler import get_client          # 기존 키/모델 설정 그대로 사용
from google.genai import types

ap = argparse.ArgumentParser()
ap.add_argument("--model")
ap.add_argument("--count", type=int, default=5)
ap.add_argument("--gap", type=float, default=1.0, help="호출 간격(초)")
a = ap.parse_args()

client, default_model = get_client()
model = a.model or default_model
print(f"model={model}  (재시도 끔, 요청당 제한 30초)\n")

try:
    http = types.HttpOptions(timeout=30_000, retry_options=types.HttpRetryOptions(attempts=1))
except AttributeError:                        # 오래된 SDK: 재시도 옵션 없음
    http = types.HttpOptions(timeout=30_000)
    print("※ 이 SDK 버전은 재시도 끄기를 지원하지 않습니다: pip install -U google-genai\n")

times, fails = [], []
for i in range(1, a.count + 1):
    t = time.perf_counter()
    try:
        r = client.models.generate_content(
            model=model, contents="Reply with exactly: OK",
            config=types.GenerateContentConfig(temperature=0, max_output_tokens=10, http_options=http),
        )
        dt = time.perf_counter() - t
        times.append(dt)
        print(f"[{i}] {dt:5.2f}s  OK   응답={(r.text or '').strip()!r}")
    except Exception as e:
        dt = time.perf_counter() - t
        code = getattr(e, "code", None) or getattr(e, "status_code", None)
        fails.append(code)
        print(f"[{i}] {dt:5.2f}s  실패 {code}  {str(e)[:160]}")
    time.sleep(a.gap)

print()
if times:
    print(f"성공 {len(times)}회: 평균 {sum(times) / len(times):.2f}s, 최소 {min(times):.2f}s, 최대 {max(times):.2f}s")
if fails:
    print(f"실패 {len(fails)}회: {fails}")
    if 429 in fails:
        print("→ 429: 요청 한도 초과. 1~2분 쉬었다 다시 해보고, AI Studio에서 이 키의 한도(RPM/RPD)를 확인하세요.")
    if 503 in fails or 500 in fails:
        print("→ 503/500: 모델 서버 과부하. --model 로 다른 모델과 비교해 보세요.")