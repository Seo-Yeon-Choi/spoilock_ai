# SPOILOCK 자막 처리 실습 — Pioneer One 1화

이 자료는 첨부받은 영어 SRT를 사용한 학습용 시작 코드입니다. 자막 파싱·정리·분할을 실제 실행했습니다. ChromaDB 적재와 임베딩 검색 코드는 포함했지만, 제작 환경에는 해당 패키지와 모델이 없어 실제 실행하지 않았습니다. 스포일러 판별 API나 LLM 사건 추출은 아직 구현하지 않았습니다.

## 1. 파일 확인 결과

- UTF-8로 읽을 수 있는 SRT, 자막 558개, 번호 1~558.
- 첫 자막 00:02:10.163. 자막이 없는 앞부분이 있다는 사실만 알 수 있으며 파일 손상으로 단정할 수 없습니다.
- 대사 마지막 시각 00:33:03.553. 영상 전체 길이를 뜻하지 않습니다.
- 마지막 558번(00:33:52.864~00:33:55.644)은 Sync 제작 크레딧입니다.
- `<i>` 태그와 한 자막 안의 여러 줄 대사, `-`로 나뉜 발언이 있습니다.
- 화자 이름이 매번 표시되는 형식은 아닙니다. 이름 없는 발언의 주체를 임의로 채우지 않습니다.
- 원본은 data/raw/ep01.srt에 이름만 바꾸어 복사했습니다. 원본 바이트는 유지했습니다.

## 2. Windows에서 시작

Python 3.11 환경을 실습 기준으로 사용합니다. 압축을 풀고 pipeline.py와 requirements.txt가 있는 폴더를 VS Code의 '폴더 열기'로 엽니다. 터미널은 PowerShell을 사용합니다. 아래 명령은 그 폴더에서 한 줄씩 실행합니다.

```powershell
py -3.11 --version
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe pipeline.py preprocess --exclude-index 558
```

3.11이 설치되지 않았으면 Python 설치 상태를 먼저 확인하세요. 다른 호환 Python을 이미 사용하고 있다면 해당 Python으로 `-m venv .venv`를 실행할 수 있습니다. 가상환경 활성화 없이 그 안의 python.exe를 직접 호출하므로 PowerShell 실행 정책 변경이 필요 없습니다.

전처리는 Python 표준 라이브러리만 사용합니다. ChromaDB나 API 키가 없어도 먼저 실행 가능합니다.

## 3. 전처리 확인

기본 설정은 최대 자막 15개, 겹침 3개, 최대 1,000문자, 자막 사이 공백이 15초를 넘으면 분리입니다. 시간 공백은 실험용 경계 규칙이지 장면 판별 AI가 아닙니다. 개별 자막 자체가 문자 제한을 넘는 경우에는 한 자막을 보존하며, 임베딩 단계에서 토큰 제한을 별도로 검사합니다.

`--exclude-index 558`은 이 파일에서 확인한 제작 크레딧만 제외합니다. 다른 회차에서 558번을 무조건 제외하면 안 됩니다.

실제 결과:

```json
{"parsed": 558, "retained": 557, "excluded": 1, "chunks": 50}
```

출력 파일:

| 경로 | 역할 |
|---|---|
| data/processed/ep01/subtitles.json | 원문 태그가 있는 raw_text와 정리된 text, 번호·시간 |
| data/processed/ep01/excluded.json | 제외한 크레딧, 삭제 내용 검토용 |
| data/processed/ep01/chunks.json | ChromaDB로 보낼 문서·메타데이터 및 근거 자막 번호 |
| data/processed/ep01/chunks_preview.txt | 사람이 문맥을 읽기 쉬운 미리보기 |
| data/processed/ep01/report.json | 처리 개수·원본 해시·분할 설정 |

미리보기에서 질문과 답변이 너무 자주 분리되는지, unrelated 대화가 한 묶음에 너무 많이 들어가는지 확인합니다. 번호 1~557 전체가 묶음에 포함되며, 겹침 때문에 일부 번호는 여러 묶음에 등장합니다. 이는 의도한 동작입니다.

연습용 drama_id=1, episode_id=101, episode_number=1을 사용했습니다. MySQL의 실제 ID를 읽어온 값이 아닙니다. 연동할 때 실제 dramas.id, episodes.id로 전처리를 다시 실행하세요.

## 4. 검색 패키지 설치

```powershell
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

requirements.txt는 호환 범위를 제시하며, 실제 설치·검색 실행을 확인한 잠금 파일은 아닙니다. 팀에서 실행에 성공하면 다음으로 설치 버전을 기록하세요.

```powershell
.\.venv\Scripts\python.exe -m pip freeze > requirements-lock.txt
```

## 5. ChromaDB 적재

```powershell
.\.venv\Scripts\python.exe pipeline.py index
```

`intfloat/multilingual-e5-small` 모델을 CPU에서 사용합니다. 첫 실행에는 인터넷을 통해 모델을 내려받고 이후 캐시를 재사용합니다. 별도 LLM API 키는 필요 없습니다. 영어 자막을 한국어로 검색하는 초기 실험용 선택이며 실제 한국어 구어체 검색 성능은 테스트해야 합니다.

1. chunks.json 로드.
2. 문서 앞에 `passage: `를 붙여 임베딩 생성.
3. 토큰 길이를 검사해 모델 입력 제한 초과 시 오류로 알림.
4. ChromaDB에 ID·원문·메타데이터·벡터를 upsert.
5. 입력 ID와 저장 ID가 일치하는지 확인.

저장 위치는 프로젝트 폴더의 chroma_data/입니다. 웹사이트에 파일을 올리는 단계가 아니라 내 PC의 영구 저장형 ChromaDB에 기록하는 작업입니다. 컬렉션명은 모델 혼합을 피하도록 episode_chunks_e5small_v1로 지정했습니다. 기존 설계의 episode_chunks 역할입니다.

성공 시 `Indexed 50 chunks ... All IDs verified.` 메시지를 기대할 수 있습니다. 이 메시지는 실행 예시이며 제작 환경에서 실제 적재가 완료됐다는 뜻이 아닙니다.

동일 입력의 재실행은 동일 ID를 갱신합니다. 동일 작품·회차·버전으로 내용이나 분할을 바꿔 넣는 것은 막았습니다. 수정할 때 새 kb_version을 사용해야 과거 판정의 근거가 바뀌지 않습니다. 적재 중 시스템 오류가 발생하면 동일 입력으로 다시 실행하고 성공 메시지를 확인하세요. 서비스용 활성 버전 전환·작업 상태 관리는 이 학습 코드의 범위 밖입니다.

## 6. 검색 실험

```powershell
.\.venv\Scripts\python.exe pipeline.py search "They found a man inside a capsule."
.\.venv\Scripts\python.exe pipeline.py search "캡슐 안에서 사람을 발견했어"
.\.venv\Scripts\python.exe pipeline.py search "오늘 저녁 뭐 먹지?"
```

첫 두 문장은 자막 531~533을 포함한 구간이 상위 5개에 들어오는지 확인하세요. 번역 표현을 바꿔서도 시험합니다. 세 번째는 작품과 무관한 문장인데도 가장 가까운 후보가 반환될 수 있다는 점을 확인하는 용도입니다. 반환 결과가 있다는 사실은 관련성이 충분하다는 뜻이 아닙니다.

각 결과는 문서 ID, 회차, 자막 시간, 코사인 거리, 영어 원문을 보여줍니다. 이 설정에서는 거리가 작을수록 벡터상 가깝지만 스포일러 확률이 아닙니다. 고정된 거리값 하나를 근거 없이 공개/차단 임계값으로 쓰지 않습니다.

검색 문자열에는 E5 규칙에 따라 `query: `를 붙입니다. 문서는 `passage: `, 질문은 `query: `로 임베딩하고 두 경우에 같은 모델을 사용합니다. 코드에서 생성한 벡터를 `query_embeddings`로 전달하므로 Chroma의 기본 임베딩 함수는 사용하지 않습니다.

## 7. LLM 사건 추출은 다음 단계

검색 연결 후 chunks.json의 문서와 인접 구간을 LLM에 전달해 사건 후보를 만듭니다. event_extraction_prompt.txt에 지침이 있습니다. 현재 프로그램에는 LLM API 호출이 없으므로 프롬프트 파일만으로 자동 실행되지는 않습니다.

단일 묶음에서 해결되지 않는 이름·지시어는 앞뒤 묶음을 함께 보고, 그래도 불확실하면 미확정으로 남깁니다. JSON 형식 검증, 근거 자막 번호 존재 검사, 인용 대사 일치 검사는 코드로 하고, 주장과 사실의 구분·최초 공개 회차는 원문 검토로 확인합니다. LLM이 출력한 needs_review=false만 믿고 verified=true로 바꾸면 안 됩니다.

이 파일 후반에는 쪽지의 내용을 전하며 화성 거주·출생에 대한 주장을 소개하는 대화가 나옵니다. 작품에서 해당 주장이 언급됐다는 것과 그 주장이 실제로 참이라는 것은 구분해야 합니다. 주장의 공개 자체도 스포일러일 수 있습니다.

## 8. 회차 확대·MySQL 연동

1화 하나만으로는 1화/2화/3화 공개 경계의 정확도를 평가할 수 없습니다. 2~3화 자료를 더하고 각 사건이 처음 공개된 회차를 비교 검토하세요. 자막에 없는 시각적 사건은 별도 확인이 필요합니다.

예: 2화 파일을 data/raw/ep02.srt에 넣고 실제 ID에 맞춰 다음 명령을 수정합니다.

```powershell
.\.venv\Scripts\python.exe pipeline.py preprocess --file data/raw/ep02.srt --episode-id 102 --episode-number 2 --out data/processed/ep02
.\.venv\Scripts\python.exe pipeline.py index --chunks data/processed/ep02/chunks.json
```

2화의 제외할 크레딧 번호는 파일을 직접 확인하고 --exclude-index로 지정합니다. 언어가 영어가 아닌 파일에는 pipeline.py의 metadata language='en'도 실제 언어에 맞춰 바꿔야 합니다.

MySQL 작품·회차 ID를 Chroma 메타데이터에 맞춘 후 FastAPI에서 작품·활성 버전으로 검색하고 LLM에 후보 근거를 전달합니다. GENERAL / EPISODE_BOUND / UNKNOWN 결과를 Spring이 저장하고 사용자 진도와 비교하는 단계는 그다음입니다. 사용자 시청 회차 이후의 근거도 검색해야 합니다.

## 9. 오류 확인

| 문제 | 확인 방법 |
|---|---|
| ModuleNotFoundError | 가상환경 python.exe로 pip 설치와 실행을 했는지 확인 |
| 모델 다운로드 실패 | 첫 실행 인터넷·Hugging Face 접근 확인, 오류 전문 확인 |
| 컬렉션 없음 | index 성공 후 search 실행 |
| No data for this drama/version | 전처리·검색의 작품 ID와 kb-version 일치 확인 |
| Text too long | 더 작은 max-chars와 새 kb-version으로 전처리·적재 |
| same episode/version different data | 변경된 데이터에 새 kb-version 지정 |
| 한국어 검색이 부정확 | 같은 의미의 영어 질문과 비교하고 묶음·모델·별명 처리 개선 |

분할 변경 예:

```powershell
.\.venv\Scripts\python.exe pipeline.py preprocess --exclude-index 558 --max-chars 700 --kb-version kb2 --out data/processed/ep01_kb2
.\.venv\Scripts\python.exe pipeline.py index --chunks data/processed/ep01_kb2/chunks.json
.\.venv\Scripts\python.exe pipeline.py search "캡슐 안에서 사람을 발견했어" --kb-version kb2
```

## 공식 참고 자료

- https://huggingface.co/intfloat/multilingual-e5-small
- https://docs.trychroma.com/reference/python/collection
- https://docs.trychroma.com/docs/collections/configure

## 실제 검증 범위

전처리 실행, 558개 파싱, 크레딧 1개 제외, 50개 묶음 생성, 557개 대사 전체 포함, ID 중복 없음, 태그 제거, 분할 길이 및 시간 공백 기준을 확인했습니다. 임베딩 모델 다운로드·추론, ChromaDB 적재·검색, LLM 사건 추출·스포일러 판정은 실행 검증하지 않았습니다.
