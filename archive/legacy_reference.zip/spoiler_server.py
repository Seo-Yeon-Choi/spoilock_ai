r"""
SPOILOCK 스포 판별 상시 실행 서버 (FastAPI)

spoiler_events_multi.py / check_spoiler.py 와 같은 폴더에 두고 실행:

  .\.venv\Scripts\python.exe -m pip install fastapi "uvicorn[standard]"
  .\.venv\Scripts\python.exe -m uvicorn spoiler_server:app --port 8000

- 서버 시작 시 torch/임베딩 모델/ChromaDB/Gemini 클라이언트를 한 번만 준비합니다.
- 판별 로직(후보 검색, 프롬프트, 캐시 키, 결과 검증, 공개 판정)은
  spoiler_events_multi.py 의 함수와 상수를 그대로 사용합니다.
  CLI에서 만든 판정 캐시(data/events/demo_match_cache)도 그대로 공유됩니다.
- Gemini 오류·시간 초과는 fail-closed(REVIEW)로 응답합니다.

확인: http://localhost:8000/docs
"""
import json
import os
import threading
import time
import uuid
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout
from contextlib import asynccontextmanager
from datetime import datetime
from hashlib import sha256
from pathlib import Path
from types import SimpleNamespace

# 이미 받아둔 임베딩 모델을 쓰므로 HF Hub 네트워크 확인을 생략 (로딩 단축)
# 모델을 새로 받아야 할 때는 실행 전에  $env:HF_HUB_OFFLINE="0"
os.environ.setdefault("HF_HUB_OFFLINE", "1")

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

import prefilter

ROOT = Path(__file__).resolve().parent
GEMINI_TIMEOUT_S = float(os.getenv("GEMINI_TIMEOUT_S", "8"))
# 1차 필터 모드: off(사용 안 함) / shadow(판단만 기록, 검사는 전부 수행) / on(통과 채팅은 Gemini 생략)
PREFILTER_MODE = os.getenv("PREFILTER_MODE", "shadow")
# 유사도 통과 임계값. calibrate_prefilter.py 결과로 정한 뒤 설정. 비우면 유사도 통과 미사용
_sim = os.getenv("PREFILTER_SIM_THRESHOLD", "").strip()
PREFILTER_SIM_THRESHOLD = float(_sim) if _sim else None
MEMORY_CACHE_SIZE = 5000
TIMING_LOG = ROOT / "data" / "tests" / "server_timing.jsonl"

S: dict = {}                       # 서버 시작 시 준비되는 자원
_mem_cache: OrderedDict = OrderedDict()
_mem_lock = threading.Lock()
_log_lock = threading.Lock()
_gemini_pool = ThreadPoolExecutor(max_workers=16)


# ---------------------------------------------------------------- 시작 준비
@asynccontextmanager
async def lifespan(app: FastAPI):
    steps = {}
    t = time.perf_counter()
    import spoiler_events_multi as base
    import check_spoiler
    steps["import"] = time.perf_counter() - t

    t = time.perf_counter()
    model = base.embedding_model()
    model.encode(["query: warmup"], normalize_embeddings=True, show_progress_bar=False)
    steps["embedding_model"] = time.perf_counter() - t

    t = time.perf_counter()
    col = base.get_collection()
    steps["chromadb"] = time.perf_counter() - t

    t = time.perf_counter()
    client, gemini_model = check_spoiler.get_client()
    steps["gemini_client"] = time.perf_counter() - t

    # 원본 함수가 매번 새로 만들던 자원을 준비된 것으로 대체
    base.embedding_model = lambda: model
    base.get_collection = lambda: col

    S.update(base=base, client=client, gemini_model=gemini_model, col=col, model=model)
    print("[startup] " + ", ".join(f"{k}={v:.1f}s" for k, v in steps.items()), flush=True)
    print(f"[startup] ready: model={gemini_model}, events={col.count()}", flush=True)
    print(f"[startup] prefilter mode={PREFILTER_MODE}, sim_threshold={PREFILTER_SIM_THRESHOLD}, "
          f"keywords={len(prefilter._KEYWORDS)}", flush=True)
    yield
    _gemini_pool.shutdown(wait=False)


app = FastAPI(title="SPOILOCK spoiler judge", lifespan=lifespan)


# ---------------------------------------------------------------- 요청/응답
class JudgeRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=2000)
    message_id: int | None = Field(None, description="Spring chat_messages.id (로그용)")
    drama_id: int = 1
    kb_version: str = "kb1"
    episodes: list[int] = Field(default_factory=lambda: [1, 2, 3, 4, 5, 6])
    retrieval: str = Field("vector", pattern="^(vector|all)$")
    top_k: int = Field(20, ge=1, le=100)
    include_evidence: bool = Field(True, description="False면 프롬프트에서 evidence 인용문 제외(실험용)")
    refresh: bool = Field(False, description="True면 캐시 무시하고 Gemini 재판정")
    watched_episode: int | None = Field(
        None, ge=0, description="데모용. 실서비스에서는 Spring이 required_episode_number로 사용자별 판정")
    prefilter_mode: str | None = Field(
        None, pattern="^(off|shadow|on)$", description="이 요청만 1차 필터 모드 변경(테스트용)")
    debug: bool = Field(False, description="True면 매칭 사건 설명 포함(테스트 페이지용, 사용자에게 노출 금지)")
    reason_mode: str = Field(
        "full", pattern="^(full|short|none)$",
        description="Gemini 판단 이유 길이. full=기존, short=15자 이내, none=생성 안 함(출력 토큰↓ → 속도↑)")


# ---------------------------------------------------------------- 판별
def _log(row: dict):
    TIMING_LOG.parent.mkdir(parents=True, exist_ok=True)
    with _log_lock, TIMING_LOG.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


REASON_SUFFIX = {
    "full": "",
    "short": "\nKeep the reason extremely short: at most 15 Korean characters.",
    "none": '\nDo not explain. Always return reason as an empty string "".',
}


def _system_prompt(reason_mode):
    return S["base"].MATCH_SYSTEM + REASON_SUFFIX[reason_mode]


def _call_gemini(prompt_candidates, message, system):
    base = S["base"]
    return S["client"].models.generate_content(
        model=S["gemini_model"],
        contents=json.dumps({"message": message, "candidates": prompt_candidates}, ensure_ascii=False),
        config={
            "system_instruction": system,
            "temperature": 0,
            "response_mime_type": "application/json",
            "response_json_schema": base.MATCH_SCHEMA,
        },
    )


def _best_similarity(req, episodes):
    """등록된 사건(시청 회차와 무관하게 전체 검색 범위)과의 최고 코사인 유사도"""
    vec = S["model"].encode(["query: " + req.message], normalize_embeddings=True,
                            show_progress_bar=False).tolist()[0]
    where = {"$and": [{"drama_id": req.drama_id}, {"kb_version": req.kb_version},
                      {"source_episode": {"$in": episodes}}]}
    d = S["col"].query(query_embeddings=[vec], where=where, n_results=1, include=["distances"])
    if not d["ids"][0]:
        return None, None
    return round(1 - d["distances"][0][0], 4), d["ids"][0][0]   # cosine space


@app.get("/")
def chat_tester():
    """채팅 형식 테스트 페이지: http://localhost:8000"""
    return FileResponse(ROOT / "chat_tester.html")


@app.get("/health")
def health():
    return {"ready": "base" in S, "gemini_model": S.get("gemini_model"),
            "events": S["col"].count() if "col" in S else None,
            "prefilter_mode": PREFILTER_MODE, "prefilter_sim_threshold": PREFILTER_SIM_THRESHOLD}


@app.post("/admin/reload-keywords")
def reload_keywords():
    """prefilter_keywords.txt 수정 후 서버 재시작 없이 다시 읽기"""
    return {"keywords": prefilter.reload_keywords()}


@app.post("/judge")
def judge(req: JudgeRequest):
    """메시지 1건 판별. sync 함수라 FastAPI가 스레드풀에서 동시 처리합니다."""
    base = S["base"]
    tm = {}
    t_all = time.perf_counter()
    episodes = sorted(set(req.episodes))
    args = SimpleNamespace(
        message=req.message, drama_id=req.drama_id, kb_version=req.kb_version,
        episodes=episodes, retrieval=req.retrieval, top_k=req.top_k,
    )

    # 0) 1차 필터
    mode = req.prefilter_mode or PREFILTER_MODE
    pf = None
    if mode != "off":
        t = time.perf_counter()
        best_sim, best_id = None, None
        if prefilter.rule_pass(req.message) is None:          # 규칙 통과면 유사도 계산 생략
            best_sim, best_id = _best_similarity(req, episodes)
        pf = prefilter.decide(req.message, best_sim, PREFILTER_SIM_THRESHOLD)
        pf.update(mode=mode, best_sim=best_sim, best_event_id=best_id)
        tm["prefilter"] = time.perf_counter() - t

        if mode == "on" and pf["decision"] == "SKIP":
            tm["total"] = time.perf_counter() - t_all
            result = {
                "message_id": req.message_id,
                # SKIPPED_GENERAL: 일반 대화 확인 / SKIPPED_UNRELATED: 등록 사건과 관련 낮음
                "analysis_verdict": "SKIPPED_GENERAL" if pf["stage"] == "rule" else "SKIPPED_UNRELATED",
                "matched_event_id": None,
                "required_episode_number": None,
                "episode_basis": "UNVERIFIED_SOURCE_EPISODE_FOR_DEMO_ONLY",
                "needs_review": False,
                "reason": None, "error": None,
                "gemini_model": None, "candidate_count": 0, "match_cache": "NONE",
                "prefilter": pf,
            }
            if req.watched_episode is not None:
                result["watched_episode_number"] = req.watched_episode
                result["visibility"] = "VISIBLE"
            result["timings_ms"] = {k: round(v * 1000, 1) for k, v in tm.items()}
            _log({"at": datetime.now().isoformat(timespec="seconds"), "message": req.message, **result})
            return result

    # 1) 후보 사건 검색 (원본 candidates_for 그대로 사용)
    t = time.perf_counter()
    try:
        candidates = base.candidates_for(base, args)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    tm["retrieval"] = time.perf_counter() - t

    prompt_candidates = []
    for e in candidates:
        item = {"event_id": e["event_id"], "description": e["description"],
                "fact_status": e["fact_status"]}
        if req.include_evidence:
            item["evidence"] = json.loads(e["evidence_json"])
        prompt_candidates.append(item)
    if req.retrieval == "all":
        prompt_candidates.sort(key=lambda item: item["event_id"])

    # 2) 캐시 키: check_message 와 동일 → CLI 캐시와 공유
    key_content = {
        "message": base.compact(req.message),
        "drama_id": req.drama_id,
        "source_episode": "MULTI:" + ",".join(map(str, episodes)),
        "kb_version": req.kb_version,
        "retrieval": req.retrieval,
        "top_k": req.top_k if req.retrieval == "vector" else None,
        "model": S["gemini_model"],
        "system": _system_prompt(req.reason_mode),   # full이면 CLI와 동일 → 캐시 공유
        "schema": base.MATCH_SCHEMA,
        "candidates": prompt_candidates,
    }
    key_text = json.dumps(key_content, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    digest = sha256(key_text.encode("utf-8")).hexdigest()
    cache_file = ROOT / "data" / "events" / "demo_match_cache" / f"{digest}.json"
    id_map = {e["event_id"]: e for e in candidates}

    answer, cache_status, error = None, "MISS", None
    if not req.refresh:
        with _mem_lock:
            if digest in _mem_cache:
                _mem_cache.move_to_end(digest)
                answer, cache_status = _mem_cache[digest], "HIT_MEMORY"
        if answer is None and cache_file.is_file():
            try:
                answer = json.loads(cache_file.read_text(encoding="utf-8")).get("answer")
                base.validate_match_answer(answer, id_map)
                cache_status = "HIT_FILE"
            except Exception:
                answer = None

    # 3) Gemini 판정 (시간 초과·오류 → fail-closed)
    if answer is None:
        t = time.perf_counter()
        try:
            fut = _gemini_pool.submit(_call_gemini, prompt_candidates, req.message,
                                      _system_prompt(req.reason_mode))
            response = fut.result(timeout=GEMINI_TIMEOUT_S)
            if not response.text:
                raise ValueError("Gemini returned an empty response")
            answer = json.loads(response.text)
            base.validate_match_answer(answer, id_map)
            u = getattr(response, "usage_metadata", None)
            if u is not None:
                tm["tokens_in"] = getattr(u, "prompt_token_count", None)
                tm["tokens_out"] = getattr(u, "candidates_token_count", None)
            cache_file.parent.mkdir(parents=True, exist_ok=True)
            tmp = cache_file.with_name(f"{digest}.{uuid.uuid4().hex}.tmp")
            tmp.write_text(json.dumps({"answer": answer}, ensure_ascii=False, indent=2), encoding="utf-8")
            try:
                tmp.replace(cache_file)
            except OSError:            # 같은 문장이 동시에 들어와 이미 저장된 경우
                tmp.unlink(missing_ok=True)
            cache_status = "REFRESHED" if req.refresh else "MISS_SAVED"
        except FutureTimeout:
            error = f"Gemini timeout > {GEMINI_TIMEOUT_S}s"
        except Exception as e:
            error = f"{type(e).__name__}: {e}"[:300]
        tm["gemini"] = time.perf_counter() - t

    # 4) 결과 정리
    if error is not None:
        verdict, matched = "ERROR", None
        cache_status = "NONE"
    else:
        with _mem_lock:
            _mem_cache[digest] = answer
            if len(_mem_cache) > MEMORY_CACHE_SIZE:
                _mem_cache.popitem(last=False)
        verdict = answer["verdict"]
        matched = id_map.get(answer["event_id"]) if verdict == "MATCH" else None

    # MATCH 이외(NO_MATCH/UNCERTAIN/ERROR)는 회차를 정할 수 없으므로 fail-closed
    required_episode = matched["source_episode"] if matched else None
    result = {
        "message_id": req.message_id,
        "analysis_verdict": verdict,                  # MATCH / NO_MATCH / UNCERTAIN / ERROR
        "matched_event_id": matched["event_id"] if matched else None,
        "required_episode_number": required_episode,  # chat_messages.required_episode_number
        "episode_basis": "UNVERIFIED_SOURCE_EPISODE_FOR_DEMO_ONLY",
        "needs_review": matched is None,              # True면 Spring은 HIDDEN/대기 처리
        "reason": answer.get("reason") if answer else None,   # 관리자용. 사용자에게 보내지 말 것
        "error": error,
        "gemini_model": S["gemini_model"],
        "candidate_count": len(candidates),
        "match_cache": cache_status,
        "prefilter": pf,       # shadow 모드: 'SKIP이었을 텐데 실제 판정은?'을 비교하는 기록
    }
    if req.debug and matched:
        result["matched_event_description"] = matched["description"]
    if req.watched_episode is not None:   # 데모 화면용 공개 판정 (원본 규칙 그대로)
        visibility, _ = base.decide_visibility(matched, req.watched_episode)
        result["watched_episode_number"] = req.watched_episode
        result["visibility"] = visibility

    tm["total"] = time.perf_counter() - t_all
    result["timings_ms"] = {k: (round(v * 1000, 1) if isinstance(v, float) else v) for k, v in tm.items()}
    _log({"at": datetime.now().isoformat(timespec="seconds"), "message": req.message, **result})
    return result
