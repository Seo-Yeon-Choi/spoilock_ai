# 기존 SPOILOCK에 Gemini 판별 추가

## 준비 및 파일 위치
압축 안의 check_spoiler.py, requirements-gemini.txt, .env.example, README_GEMINI.md, gitignore-additions.txt를 기존 C:\spoilock_subtitle_starter 폴더로 복사하세요. check_spoiler.py와 기존 pipeline.py가 같은 폴더에 있어야 합니다. 기존 pipeline.py, .venv, chroma_data를 교체하거나 지우지 않습니다.

## 1. 추가 패키지 설치
PowerShell의 PS C:\spoilock_subtitle_starter>에서 실행합니다. >>> 파이썬 대화형 모드에 있다면 exit()로 나옵니다.

```powershell
.\.venv\Scripts\python.exe -m pip install --upgrade -r requirements-gemini.txt
```

## 2. .env 설정
VS Code에서 프로젝트 폴더 바로 아래에 `.env`라는 새 파일을 만듭니다. `.env.txt`가 되지 않도록 확인하세요. .env.example의 내용을 복사하고 자신의 키를 넣습니다.

```dotenv
GEMINI_API_KEY=여기에_본인의_키
GEMINI_MODEL=gemini-3.5-flash-lite
```

코드는 스크립트 옆 .env를 명시적으로 읽습니다. 그 파일의 키가 있으면 셸 환경변수보다 우선합니다. API 키는 공유하지 않습니다. gitignore-additions.txt의 줄을 기존 .gitignore 끝에 추가하세요. 기존 .gitignore를 덮어쓰지 않습니다. 이미 Git에 커밋한 키는 .gitignore만으로 보호되지 않으므로 재발급이 필요합니다.

## 3. API만 연결 확인
```powershell
.\.venv\Scripts\python.exe check_spoiler.py --ping
```
connection: OK와 모델 응답이 나오면 연결 성공입니다. 실제 API 요청 1회가 발생하며 프로젝트의 할당량을 사용합니다. 결제 계정에 연결된 프로젝트라면 프로젝트 과금 설정이 적용됩니다.

404일 때:
```powershell
.\.venv\Scripts\python.exe check_spoiler.py --list-models
```
목록은 모델 존재/지원 작업을 확인하는 용도이지 무료 사용 보장이 아닙니다. AI Studio의 해당 프로젝트 할당량과 공식 가격표를 확인하고 .env의 GEMINI_MODEL을 변경합니다. 모델을 자동으로 다른 유료 모델로 전환하지 않습니다.

## 4. 기존 검색과 Gemini 연결
```powershell
.\.venv\Scripts\python.exe check_spoiler.py "It was some sort of capsule. We found him inside."
```
기본 top-k는 10입니다. 기존 검색에서 7위였던 c0048이 후보에 포함되는지 출력 첫 줄에서 확인합니다. 이 코드는 pipeline.py의 load_model/encode를 재사용합니다. 문장과 검색된 원문 10개를 Gemini에 전달하므로 입력 자료가 Google API로 전송됩니다. 원본 전체를 업로드하거나 모델을 재학습하는 작업은 아닙니다.

결과의 verdict, evidence, reason을 읽습니다. 기대 방향은 EPISODE_BOUND이며 c0048의 관련 대사를 근거로 선택하는 것입니다. 이는 기대값이며 실측 결과가 아닙니다. 다른 정확한 근거가 선택되는 경우도 원문을 보고 평가합니다.

## 5. 비교 테스트 (각 명령마다 API 요청 발생)
```powershell
.\.venv\Scripts\python.exe check_spoiler.py "They found a man inside a capsule."
.\.venv\Scripts\python.exe check_spoiler.py "캡슐 안에서 사람을 발견했어"
.\.venv\Scripts\python.exe check_spoiler.py "오늘 저녁 뭐 먹지?"
.\.venv\Scripts\python.exe check_spoiler.py "그 사람이 결국 배신하네"
```
앞의 두 개는 EPISODE_BOUND를 기대합니다. 후보에 직접 근거가 없다면 UNKNOWN이 더 정직한 결과일 수 있습니다. 식사 질문은 GENERAL, 마지막은 인물과 사건이 불명확하므로 UNKNOWN을 기대합니다. 기대와 다른 결과가 나오면 후보 ID·판정·근거를 함께 비교하고 프롬프트나 검색을 개선하세요.

## 결과 필드
- analysis_status=COMPLETED: API 응답 및 구조/참조 검증이 완료됨. 내용이 반드시 맞다는 뜻은 아님.
- GENERAL: 일반 대화. predicted_episode_number=0.
- EPISODE_BOUND: 구체적 작품 정보가 근거에 의해 뒷받침됨. 선택된 근거 자막의 가장 큰 회차를 predicted_episode_number로 반환.
- UNKNOWN: 작품 정보 여부 또는 근거가 불충분. predicted_episode_number=null.
- FAILED: API/설정/검색/응답 검증 오류. verdict=null. 일반 대화로 공개하면 안 됨.
- evidence: Gemini가 선택한 후보 ID, 원문 인용, 자막 회차.
- reason: 개발자용 판정 설명. 스포일러가 포함될 수 있으므로 사용자 화면에 그대로 노출하지 않음.

## 코드의 검증
응답 스키마를 요청하고, verdict 값·필수 필드·후보에 존재하는 ID·원문에 존재하는 인용문·판정과 근거의 일관성을 검사합니다. 실패하면 FAILED로 종료합니다. 근거 문장이 실제로 주장을 뒷받침하는지까지 이 검사가 보증하지 않습니다. 그것은 실제 평가 사례와 원문 검토로 확인해야 합니다.

## 중요한 범위 제한
현재 코드는 최초 공개 회차 계산기가 아닙니다. 4화 자막에서 2화 사건을 회상하는 경우, 자막 회차만으로 최초 공개 회차를 정할 수 없습니다. 그래서 episode_basis에 MAX_CITED_SUBTITLE_EPISODE_NOT_VERIFIED_FIRST_REVEAL을 표시합니다. 검토된 사건과 first_reveal_episode를 연결하기 전에는 이 결과를 서비스의 확정 공개 기준으로 쓰지 마세요.

현재 1화로 관련성·근거 선택·일반 대화 구분을 실험하고, 이후 사건 추출/검토와 다회차 평가를 추가합니다. 화성 관련 쪽지의 주장은 진위가 확정된 사실과 구분해야 합니다. 검색 실패를 GENERAL로 돌리지 않도록 지시했지만 모델 오류가 완전히 방지되지는 않습니다.

## 오류 처리
- ModuleNotFoundError: 같은 .venv의 python.exe로 추가 패키지 설치.
- CONFIG 실패: 스크립트 옆 .env, GEMINI_API_KEY 값 및 설치 상태 확인.
- 400/401/403: 키 유효성·프로젝트 접근·SDK/요청 지원 확인.
- 404: 모델명 확인; --list-models 실행. 무료 할당량은 별도 확인.
- 429: AI Studio에서 분당/일일 할당량 확인. 연속 재시도하지 않음.
- RETRIEVAL 실패: pipeline.py 및 chroma_data 위치, 작품 ID, kb_version 확인.
- RESPONSE_VALIDATION 실패: 잘못된 JSON/근거 ID/인용 또는 빈 응답 가능. 일반 대화로 처리하지 않음.
- Timeout/503: 서비스 상태·네트워크 확인 후 나중에 수동 재시도.

키 노출을 피하려고 API 예외 전문 대신 단계·오류 유형·HTTP 코드를 출력합니다. 이 코드에는 별도의 자동 재시도 루프가 없습니다.

## 검증 범위와 출처
Python 구문과 로컬 응답 검증 분기를 확인했습니다. 사용자 API 키가 없으므로 Gemini 실제 호출, 사용자 PC의 Chroma 연동 및 판정 정확도는 실행 검증하지 않았습니다.

https://ai.google.dev/gemini-api/docs/generate-content/structured-output
https://ai.google.dev/gemini-api/docs/models/gemini-3.5-flash-lite
https://ai.google.dev/gemini-api/docs/pricing
