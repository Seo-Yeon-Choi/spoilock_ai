
import chromadb
from collections import Counter
from pathlib import Path
from pipeline import COLLECTION

ROOT = Path(__file__).resolve().parent

client = chromadb.PersistentClient(
    path=str(ROOT / "chroma_data")
)

collection = client.get_collection(COLLECTION)

data = collection.get(
    where={
        "$and": [
            {"drama_id": 1},
            {"kb_version": "kb1"}
        ]
    },
    include=["metadatas"]
)

counts = Counter(
    meta["episode_number"]
    for meta in data["metadatas"]
)

print("=== ChromaDB 회차별 데이터 ===")

for episode, count in sorted(counts.items()):
    print(f"{episode}화: {count}개 청크")

print(f"전체: {len(data['ids'])}개 청크")
