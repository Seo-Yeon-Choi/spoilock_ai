"""SRT preprocessing and multilingual Chroma retrieval tutorial (Python 3.11+)."""
import argparse
import hashlib
import html
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MODEL = 'intfloat/multilingual-e5-small'
COLLECTION = 'episode_chunks_e5small_v1'
TIME = r'(\d{2}:\d{2}:\d{2},\d{3})'
BLOCK = re.compile(r'^(\d+)\n' + TIME + r'\s*-->\s*' + TIME + r'\n([\s\S]+)$')


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def millis(value):
    h, m, s, ms = map(int, re.split('[:,]', value))
    if m >= 60 or s >= 60:
        raise ValueError(f'Invalid timestamp: {value}')
    return ((h * 60 + m) * 60 + s) * 1000 + ms


def timestamp(ms):
    s, rem = divmod(ms, 1000)
    h, s = divmod(s, 3600)
    m, s = divmod(s, 60)
    return f'{h:02}:{m:02}:{s:02}.{rem:03}'


def parse_srt(path):
    text = path.read_text(encoding='utf-8-sig').replace('\r\n', '\n').replace('\r', '\n')
    rows, seen = [], set()
    for pos, block in enumerate(re.split(r'\n\s*\n', text.strip()), 1):
        match = BLOCK.fullmatch(block.strip())
        if not match:
            raise ValueError(f'Invalid SRT block at position {pos}; not skipped silently.')
        index, start, end, raw = match.groups()
        index, start, end = int(index), millis(start), millis(end)
        if index in seen or end < start or (rows and start < rows[-1]['start_ms']):
            raise ValueError(f'Duplicate index or invalid time order: {index}')
        seen.add(index)
        cleaned = html.unescape(re.sub(r'<[^>]+>', '', raw))
        cleaned = '\n'.join(re.sub(r'[ \t]+', ' ', line).strip() for line in cleaned.splitlines()).strip()
        if not cleaned:
            raise ValueError(f'Empty subtitle: {index}')
        rows.append(dict(subtitle_index=index, start_ms=start, end_ms=end, raw_text=raw, text=cleaned))
    return rows


def make_chunks(rows, window, overlap, max_chars, gap_ms):
    if window < 1 or not 0 <= overlap < window or max_chars < 1 or gap_ms < 0:
        raise ValueError('Require window > overlap >= 0, max_chars > 0 and gap_ms >= 0')
    i = 0
    while i < len(rows):
        j, size, hard_gap = i, 0, False
        while j < len(rows) and j - i < window:
            if j > i and rows[j]['start_ms'] - rows[j-1]['end_ms'] > gap_ms:
                hard_gap = True
                break
            extra = len(rows[j]['text']) + (1 if j > i else 0)
            if j > i and size + extra > max_chars:
                break
            size += extra
            j += 1
        yield rows[i:j]
        if j == len(rows):
            break
        i = j if hard_gap else max(i + 1, j - overlap)


def preprocess(args):
    rows = parse_srt(Path(args.file))
    excluded_ids = set(args.exclude_index)
    missing = excluded_ids - {r['subtitle_index'] for r in rows}
    if missing:
        raise ValueError(f'Excluded indices do not exist: {sorted(missing)}')
    selected = [r for r in rows if r['subtitle_index'] not in excluded_ids]
    if not selected:
        raise ValueError('No subtitles retained')
    records = []
    for n, group in enumerate(make_chunks(selected, args.window, args.overlap, args.max_chars, args.gap_ms), 1):
        records.append({
            'id': f'd{args.drama_id}-e{args.episode_id}-{args.kb_version}-c{n:04}',
            'document': '\n'.join(r['text'] for r in group),
            'metadata': dict(drama_id=args.drama_id, episode_id=args.episode_id,
                episode_number=args.episode_number, kb_version=args.kb_version,
                language='en', source_file=Path(args.file).name, chunk_index=n,
                start_ms=group[0]['start_ms'], end_ms=max(r['end_ms'] for r in group),
                subtitle_start=group[0]['subtitle_index'], subtitle_end=group[-1]['subtitle_index']),
            'subtitle_indices': [r['subtitle_index'] for r in group]
        })
    out = Path(args.out)
    dump(out / 'subtitles.json', rows)
    dump(out / 'excluded.json', [r for r in rows if r['subtitle_index'] in excluded_ids])
    dump(out / 'chunks.json', records)
    report = dict(parsed=len(rows), retained=len(selected), excluded=len(rows)-len(selected), chunks=len(records),
        first_timestamp=timestamp(rows[0]['start_ms']), last_dialogue_timestamp=timestamp(selected[-1]['end_ms']),
        source_sha256=hashlib.sha256(Path(args.file).read_bytes()).hexdigest(),
        settings=dict(window=args.window, overlap=args.overlap, max_chars=args.max_chars, gap_ms=args.gap_ms),
        note='IDs are local practice values until matched to MySQL. No LLM extraction or spoiler decision performed.')
    dump(out / 'report.json', report)
    preview = []
    for r in records:
        m = r['metadata']
        preview.append(f"[{r['id']}] subtitles {m['subtitle_start']}-{m['subtitle_end']} | "
            f"{timestamp(m['start_ms'])} ~ {timestamp(m['end_ms'])}\n{r['document']}")
    (out / 'chunks_preview.txt').write_text('\n\n'.join(preview), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


def load_model():
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer(MODEL, device='cpu')


def encode(model, texts):
    # Refuse silent truncation. Change chunk settings / KB version if too long.
    lengths = [len(model.tokenizer(t, truncation=False)['input_ids']) for t in texts]
    if max(lengths) > model.max_seq_length:
        raise ValueError(f'Text too long: {max(lengths)} tokens; model limit {model.max_seq_length}. '
            'Reduce --max-chars, use a new --kb-version, preprocess and index again.')
    return model.encode(texts, normalize_embeddings=True, show_progress_bar=True).tolist()


def index(args):
    import chromadb
    records = json.loads(Path(args.chunks).read_text(encoding='utf-8'))
    if not records:
        raise ValueError('Empty chunks file')
    if len({r['id'] for r in records}) != len(records):
        raise ValueError('Duplicate chunk IDs')
    scopes = {(r['metadata']['drama_id'], r['metadata']['episode_id'], r['metadata']['kb_version']) for r in records}
    if len(scopes) != 1:
        raise ValueError('Index one episode/version per input file')
    fingerprint = hashlib.sha256(json.dumps(records, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    client = chromadb.PersistentClient(path=str(ROOT / 'chroma_data'))
    collection = client.get_or_create_collection(name=COLLECTION, embedding_function=None,
        configuration={'hnsw': {'space': 'cosine'}}, metadata={'embedding_model': MODEL})
    if (collection.metadata or {}).get('embedding_model') != MODEL:
        raise ValueError('Embedding model mismatch; use a different collection')
    drama, episode, version = next(iter(scopes))
    where = {'$and': [{'drama_id': drama}, {'episode_id': episode}, {'kb_version': version}]}
    existing = collection.get(where=where, include=['metadatas'])
    if any(m.get('input_fingerprint') != fingerprint for m in existing['metadatas']):
        raise ValueError('This episode/version already has different data. Use a new --kb-version.')
    model = load_model()
    # Encode before writing so token errors do not leave partially updated data.
    vectors = encode(model, ['passage: ' + r['document'] for r in records])
    for begin in range(0, len(records), 64):
        batch = records[begin:begin+64]
        collection.upsert(ids=[r['id'] for r in batch], documents=[r['document'] for r in batch],
            metadatas=[dict(r['metadata'], input_fingerprint=fingerprint) for r in batch],
            embeddings=vectors[begin:begin+64])
    actual = collection.get(where=where, include=[])['ids']
    if set(actual) != {r['id'] for r in records}:
        raise ValueError('Index verification failed')
    print(f'Indexed {len(records)} chunks into {COLLECTION}. All IDs verified.')


def search(args):
    import chromadb
    if not args.text.strip() or args.top_k < 1:
        raise ValueError('Require a nonempty query and top-k > 0')
    client = chromadb.PersistentClient(path=str(ROOT / 'chroma_data'))
    collection = client.get_collection(COLLECTION, embedding_function=None)
    if (collection.metadata or {}).get('embedding_model') != MODEL:
        raise ValueError('Embedding model mismatch')
    where = {'$and': [{'drama_id': args.drama_id}, {'kb_version': args.kb_version}]}
    count = len(collection.get(where=where, include=[])['ids'])
    if not count:
        raise ValueError('No data for this drama/version. Run index first.')
    vector = encode(load_model(), ['query: ' + args.text])
    result = collection.query(query_embeddings=vector, n_results=min(args.top_k, count), where=where,
        include=['documents', 'metadatas', 'distances'])
    for ident, doc, meta, distance in zip(result['ids'][0], result['documents'][0], result['metadatas'][0], result['distances'][0]):
        print(f"\n[{ident}] cosine distance={distance:.4f}, episode={meta['episode_number']}, "
            f"{timestamp(meta['start_ms'])} ~ {timestamp(meta['end_ms'])}")
        print(doc)
    print('\nRetrieval candidates only: distance is NOT a spoiler probability.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    p = commands.add_parser('preprocess')
    p.add_argument('--file', default=str(ROOT / 'data/raw/ep01.srt'))
    p.add_argument('--out', default=str(ROOT / 'data/processed/ep01'))
    p.add_argument('--drama-id', type=int, default=1)
    p.add_argument('--episode-id', type=int, default=101)
    p.add_argument('--episode-number', type=int, default=1)
    p.add_argument('--kb-version', default='kb1')
    p.add_argument('--window', type=int, default=15)
    p.add_argument('--overlap', type=int, default=3)
    p.add_argument('--max-chars', type=int, default=1000)
    p.add_argument('--gap-ms', type=int, default=15000)
    p.add_argument('--exclude-index', type=int, nargs='*', default=[])
    p.set_defaults(run=preprocess)
    p = commands.add_parser('index')
    p.add_argument('--chunks', default=str(ROOT / 'data/processed/ep01/chunks.json'))
    p.set_defaults(run=index)
    p = commands.add_parser('search')
    p.add_argument('text')
    p.add_argument('--drama-id', type=int, default=1)
    p.add_argument('--kb-version', default='kb1')
    p.add_argument('--top-k', type=int, default=5)
    p.set_defaults(run=search)
    args = parser.parse_args()
    args.run(args)


if __name__ == '__main__':
    main()
