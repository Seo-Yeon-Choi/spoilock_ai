r"""
spoiler_events_multi.py 단계별 시간 측정기 (원본 코드는 수정하지 않음)

spoiler_events_multi.py 와 같은 폴더에 두고, 기존 명령에서 파일 이름만 바꿔 실행:

  .\.venv\Scripts\python.exe timing_check.py check "러시아 측이 ..." --watched-episode 4 --refresh-match

추가 옵션 (이 스크립트 전용):
  --repeat N            같은 프로세스에서 N번 반복. 1회차=콜드(모델 로딩 포함),
                        2회차부터=웜(서버로 상시 실행했을 때의 시간에 해당)
  --thinking-budget N   Gemini thinking 예산을 강제로 지정 (0 = 끄기). 미지정 시 원본 설정 그대로

※ Gemini 호출 시간을 재려면 --refresh-match 를 꼭 붙이세요.
  안 붙이면 두 번째부터 캐시 HIT 이 되어 Gemini를 호출하지 않습니다.
결과는 화면 출력 + data/tests/timing_log.jsonl 에 한 줄씩 누적 저장됩니다.
"""
import argparse
import json
import sys
import time
from datetime import datetime
from pathlib import Path

T_PROCESS = time.perf_counter()
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

# ------------------------------------------------------------------ 기록 도구
run_times: dict = {}
run_tokens: dict = {}


def rec(name, sec):
    run_times[name] = run_times.get(name, 0.0) + sec


def timed(name, fn):
    def wrapper(*a, **k):
        t = time.perf_counter()
        try:
            return fn(*a, **k)
        finally:
            rec(name, time.perf_counter() - t)
    return wrapper


def timed_import(label, stmt):
    t = time.perf_counter()
    exec(stmt, globals())
    return label, time.perf_counter() - t


# ------------------------------------------------------------------ 전용 옵션 분리
wp = argparse.ArgumentParser(add_help=False)
wp.add_argument("--repeat", type=int, default=1)
wp.add_argument("--thinking-budget", type=int, default=None)
wargs, passthrough = wp.parse_known_args()

# ------------------------------------------------------------------ 1. 라이브러리 import 시간
import_times = [
    timed_import("import chromadb", "import chromadb"),
    timed_import("import sentence_transformers(torch 포함)", "import sentence_transformers"),
    timed_import("import google.genai", "from google import genai"),
    timed_import("import check_spoiler", "import check_spoiler"),
    timed_import("import spoiler_events_multi", "import spoiler_events_multi as base"),
]

# ------------------------------------------------------------------ 2. 원본 함수 감싸기
class _Proxy:
    """지정한 메서드만 시간 측정하고 나머지는 원본 객체로 전달"""
    def __init__(self, obj, methods):
        self._obj, self._methods = obj, methods

    def __getattr__(self, name):
        attr = getattr(self._obj, name)
        if name in self._methods:
            return timed(self._methods[name], attr)
        return attr


_orig_get_collection = base.get_collection
base.get_collection = lambda: _Proxy(
    timed("ChromaDB 열기", _orig_get_collection)(),
    {"query": "ChromaDB 벡터검색(query)", "get": "ChromaDB 조회(get)"},
)

# 임베딩 모델: 1회차에만 로딩하고 이후 재사용 (상시 서버와 같은 조건)
_model_holder = {}
_orig_embedding_model = base.embedding_model


def _embedding_model():
    if "m" not in _model_holder:
        _model_holder["m"] = timed("임베딩 모델 로딩", _orig_embedding_model)()
    return _Proxy(_model_holder["m"], {"encode": "메시지 임베딩(encode)"})


base.embedding_model = _embedding_model


class _ModelsProxy:
    def __init__(self, models):
        self._m = models

    def __getattr__(self, name):
        return getattr(self._m, name)

    def generate_content(self, **kw):
        if wargs.thinking_budget is not None:
            cfg = dict(kw.get("config") or {})
            cfg["thinking_config"] = {"thinking_budget": wargs.thinking_budget}
            kw["config"] = cfg
        t = time.perf_counter()
        resp = self._m.generate_content(**kw)
        rec("Gemini 호출", time.perf_counter() - t)
        u = getattr(resp, "usage_metadata", None)
        if u is not None:
            run_tokens.update({
                "입력 토큰": getattr(u, "prompt_token_count", None),
                "출력 토큰": getattr(u, "candidates_token_count", None),
                "thinking 토큰": getattr(u, "thoughts_token_count", None),
            })
        run_tokens["모델"] = kw.get("model")
        return resp


class _ClientProxy:
    def __init__(self, client):
        self._c = client
        self.models = _ModelsProxy(client.models)

    def __getattr__(self, name):
        return getattr(self._c, name)


_client_holder = {}
_orig_get_client = check_spoiler.get_client


def _get_client():
    if "c" not in _client_holder:
        client, model = timed("Gemini 클라이언트 준비", _orig_get_client)()
        _client_holder["c"] = (_ClientProxy(client), model)
    return _client_holder["c"]


check_spoiler.get_client = _get_client

# 원본 main()이 매번 덮어쓰는 함수들을 반복 실행 전에 되돌리기 위해 보관
_orig_build_display = base.build_display
_orig_get_candidates = base.get_candidates

# ------------------------------------------------------------------ 3. 실행
STEP_ORDER = [
    "ChromaDB 열기", "ChromaDB 조회(get)", "임베딩 모델 로딩", "메시지 임베딩(encode)",
    "ChromaDB 벡터검색(query)", "Gemini 클라이언트 준비", "Gemini 호출",
]
log_path = ROOT / "data" / "tests" / "timing_log.jsonl"
log_path.parent.mkdir(parents=True, exist_ok=True)
summary = []

print("\n========== import 시간 (프로세스당 1회) ==========")
for label, sec in import_times:
    print(f"{label:40s} {sec:7.2f}s")
import_total = sum(s for _, s in import_times)

for i in range(1, wargs.repeat + 1):
    run_times.clear()
    run_tokens.clear()
    base.build_display = _orig_build_display
    base.get_candidates = _orig_get_candidates
    sys.argv = ["spoiler_events_multi.py", *passthrough]

    t = time.perf_counter()
    base.main()
    total = time.perf_counter() - t

    measured = sum(run_times.values())
    label = "콜드(모델 로딩 포함)" if i == 1 else "웜(상시 서버 조건)"
    print(f"\n========== {i}회차 단계별 시간 · {label} ==========")
    for name in STEP_ORDER:
        if name in run_times:
            sec = run_times[name]
            print(f"{name:32s} {sec:7.2f}s  {sec / total * 100:5.1f}%")
    print(f"{'기타(캐시·검증·출력·파일저장)':32s} {total - measured:7.2f}s")
    print(f"{'합계':32s} {total:7.2f}s")
    if run_tokens:
        print("--- Gemini ---")
        for k, v in run_tokens.items():
            print(f"{k:32s} {v}")
    elif "Gemini 호출" not in run_times:
        print("(Gemini 미호출: 캐시 HIT. Gemini 시간을 재려면 --refresh-match 추가)")

    summary.append(total)
    with log_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps({
            "at": datetime.now().isoformat(timespec="seconds"),
            "run": i, "args": passthrough,
            "thinking_budget": wargs.thinking_budget,
            "steps_s": {k: round(v, 3) for k, v in run_times.items()},
            "total_s": round(total, 3),
            "import_s": round(import_total, 3) if i == 1 else 0,
            "tokens": run_tokens,
        }, ensure_ascii=False) + "\n")

print("\n========== 요약 ==========")
print(f"{'import 합계':32s} {import_total:7.2f}s")
for i, s in enumerate(summary, 1):
    print(f"{f'{i}회차 판별':32s} {s:7.2f}s")
print(f"{'스크립트 전체(파이썬 시작 제외)':32s} {time.perf_counter() - T_PROCESS:7.2f}s")
print(f"로그: {log_path}")